# midoc 1.0.0

## Changes coming in version 1.0

* Initial CRAN submission.


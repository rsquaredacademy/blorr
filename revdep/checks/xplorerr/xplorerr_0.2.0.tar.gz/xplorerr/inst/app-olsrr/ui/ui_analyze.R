navbarMenu('Analyze', icon = icon('search-plus'),
	source('ui/ui_homes.R', local = TRUE)[[1]],
  source('ui/ui_mlr.R', local = TRUE)[[1]]
)
